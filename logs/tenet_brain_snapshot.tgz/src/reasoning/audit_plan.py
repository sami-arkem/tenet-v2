from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List

from src.core.contracts import validate_audit_context


CONTROL_LIBRARY_PATH = Path("data/config/control_library_v1.json")
REGIME_MAP_PATH = Path("data/config/regime_map_v1.json")


@dataclass
class AuditPlan:
    audit_type: str
    industry: str
    jurisdictions: List[str]
    applicable_regimes: List[str]
    required_control_ids: List[str]
    required_evidence_types: List[str]
    review_focus: List[str]
    decision_sensitivity: str


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def load_control_library(path: Path = CONTROL_LIBRARY_PATH) -> List[Dict[str, Any]]:
    return load_json(path)


def load_regime_map(path: Path = REGIME_MAP_PATH) -> Dict[str, Dict[str, List[str]]]:
    return load_json(path)


def select_regimes(audit_type: str, jurisdictions: List[str]) -> List[str]:
    regime_map = load_regime_map()
    selected: List[str] = []
    for jurisdiction in jurisdictions:
        selected.extend(regime_map.get(audit_type, {}).get(jurisdiction, []))
    return sorted(set(selected))


def build_audit_plan(audit_context: Dict[str, Any]) -> AuditPlan:
    errors = validate_audit_context(audit_context)
    if errors:
        raise ValueError("Invalid audit_context: " + " | ".join(errors))

    audit_type = audit_context["audit_type"]
    industry = audit_context["industry"]
    jurisdictions = audit_context["jurisdictions"]

    library = load_control_library()
    applicable_regimes = select_regimes(audit_type, jurisdictions)

    selected_controls: List[Dict[str, Any]] = []
    for control in library:
        if audit_type not in control.get("audit_types", []):
            continue
        if industry not in control.get("industries", []):
            continue
        if not any(j in control.get("jurisdictions", []) for j in jurisdictions):
            continue
        selected_controls.append(control)

    required_control_ids = sorted({c["control_id"] for c in selected_controls})
    required_evidence_types = sorted({
        evidence
        for control in selected_controls
        for evidence in control.get("required_evidence", [])
    })
    review_focus = sorted({control.get("domain", "") for control in selected_controls if control.get("domain")})

    decision_sensitivity = "critical" if audit_type in {
        "aml_readiness_review",
        "sanctions_readiness_review",
    } else "high"

    return AuditPlan(
        audit_type=audit_type,
        industry=industry,
        jurisdictions=jurisdictions,
        applicable_regimes=applicable_regimes,
        required_control_ids=required_control_ids,
        required_evidence_types=required_evidence_types,
        review_focus=review_focus,
        decision_sensitivity=decision_sensitivity,
    )


def audit_plan_to_dict(plan: AuditPlan) -> Dict[str, Any]:
    return asdict(plan)
