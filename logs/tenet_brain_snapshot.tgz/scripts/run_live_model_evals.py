import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import json
from pathlib import Path
from evals.loader import load_eval_cases
from evals.runner import run_eval_case
from src.reasoning.model_reasoner import ModelReasoner

cases = load_eval_cases("evals/gold_cases")
reasoner = ModelReasoner()
results = []

for i, case in enumerate(cases, 1):
    case.audit_context["reasoning_model_name"] = "gpt-4.1-mini"
    case.audit_context["top_k"] = 3
    print(f"running {i}/{len(cases)}: {case.case_id}")

    r = run_eval_case(
        case,
        runtime_config={
            "enable_model_reasoning": True,
            "model_overlay_sections": [
                "executive_summary",
                "reporting_outputs"
            ],
            "fallback_to_deterministic_on_model_error": False,
            "require_retrieved_chunks_for_model_reasoning": True
        },
        reasoner=reasoner,
    )

    results.append({
        "case_id": r.case_id,
        "passed": r.passed,
        "weighted_score": r.weighted_score,
        "failures": r.failures
    })

out = Path("logs/evals/live_model_eval_summary.json")
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(results, indent=2), encoding="utf-8")
print(json.dumps(results, indent=2))
