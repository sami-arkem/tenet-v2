# vendor_readiness_us_uk

## Scenario
Vendor/internal compliance readiness review for a US + UK payments vendor case.

## Human adjudication
Expected outcome is CONDITIONALLY_APPROVED.

## Expected regimes
- GOVERNANCE_BASELINE
- THIRD_PARTY_RISK

## Expected control position
- GOV-001 remains partial/unknown
- VEN-001 remains partial/unknown

## Reviewer rationale
The corpus supports some governance/oversight signals but not enough for a clean pass.
