Real adjudicated AML readiness case.
Expected to be BLOCKED based on current evidence and missing transaction monitoring proof.
