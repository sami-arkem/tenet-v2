# kyb_us_beneficial_ownership_gap

## Scenario
KYC/KYB policy and control review for a US case.

## Observed output
- decision: BLOCKED
- regimes: CDD_BO, CIP_KYC
- missing controls: AML-002, KYB-001, KYC-001
- missing evidence: AML-002, KYB-001, KYC-001
- findings include: AML-002, KYB-001, KYC-001

## Human adjudication
Current expected outcome is BLOCKED because customer risk rating, beneficial ownership/business verification, and customer identification controls are not sufficiently demonstrated.

## Reviewer rationale
This case is intended to verify that Tenet correctly blocks when core KYC/KYB readiness controls are absent or inadequately evidenced.
