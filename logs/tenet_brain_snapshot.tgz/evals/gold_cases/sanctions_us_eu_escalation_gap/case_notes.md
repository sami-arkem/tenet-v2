# sanctions_us_eu_escalation_gap

## Scenario
Sanctions readiness review for a US + EU case.

## Observed output
- decision: CONDITIONALLY_APPROVED
- regimes: EU_SANCTIONS, OFAC
- missing control: SAN-001
- missing evidence: SAN-001
- findings include: SAN-001

## Human adjudication
Current expected outcome is CONDITIONALLY_APPROVED, with sanctions screening program definition and evidence still incomplete.

## Reviewer rationale
This case is intended to verify that Tenet identifies sanctions screening scope and governance weakness without collapsing the case into unrelated AML/KYB controls.
