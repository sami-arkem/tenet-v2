# governance_gap_eu

## Scenario
Policy/governance gap analysis for an EU fintech case.

## Human adjudication
Expected outcome is BLOCKED.

## Expected regimes
- GOVERNANCE_BASELINE
- THIRD_PARTY_RISK

## Expected control position
- AML-001 unknown/partial
- GOV-001 unknown/partial
- VEN-001 missing

## Reviewer rationale
The corpus shows limited governance evidence and a clear vendor oversight gap.
