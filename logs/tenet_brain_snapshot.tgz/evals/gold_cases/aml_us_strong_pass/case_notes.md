# aml_us_strong_pass

## Scenario
AML readiness review for a US fintech case.

## Actual corpus behavior
Current retrieval corpus does not contain evidence sufficient to support a strong-pass outcome.
The current adjudicated deterministic output is BLOCKED.

## Human adjudication
Use the current observed output as the gold baseline until a true strong-pass evidence pack exists.

## Expected regimes
- BSA_AML
- CDD_BO
- CIP_KYC

## Reviewer rationale
This folder name is now misleading relative to the current corpus. Keep it only as a baseline case for the current data state, or rename later once a true strong-pass evidence pack exists.
